
import unittest

class TestInference(unittest.TestCase):
    def test_generate_lyrics(self):
        self.assertEqual("Generated lyrics for prompt: test", "Generated lyrics for prompt: test")
