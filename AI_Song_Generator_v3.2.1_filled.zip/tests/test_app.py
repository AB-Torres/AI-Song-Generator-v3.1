
import unittest

class TestApp(unittest.TestCase):
    def test_health_check(self):
        self.assertEqual(200, 200)
