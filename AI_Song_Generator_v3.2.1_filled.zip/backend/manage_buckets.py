
import logging

def upload_file_to_s3(file_name, bucket, object_name=None):
    logging.info(f"Uploading {file_name} to bucket {bucket}")
    return True
