
import unittest

class TestEndpoints(unittest.TestCase):
    def test_health_check(self):
        self.assertEqual(200, 200)
