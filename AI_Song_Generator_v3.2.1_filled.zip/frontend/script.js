
console.log("Frontend script loaded");
